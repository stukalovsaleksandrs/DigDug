// Project
#include "Application.h"
// Third-party
#include "SDL3/SDL_main.h"// Required for the windows build not to give errors
#if _DEBUG && __has_include(<vld.h>)
#include <vld.h>
#endif

int main(int, char*[]) {
    Game::Application game{};
    game.Run();
    return SDL_APP_SUCCESS;
}

// #include <SDL3/SDL.h>
// #include <SDL3_image/SDL_image.h>
// #include <vector>
// #include <cmath>
//
// const int LOGICAL_WIDTH = 224;
// const int LOGICAL_HEIGHT = 288;
// const int WINDOW_WIDTH = 448;   // 2x scale
// const int WINDOW_HEIGHT = 576;  // 2x scale
//
// struct Player {
//     float x, y;
//     float speed = 75.0f;  // Reduced speed for smaller resolution
//     float dirX = 0, dirY = 0;
//     float radius = 8.0f;  // Smaller player for the resolution
// };
//
// class DigDugGame {
// private:
//     SDL_Renderer* renderer;
//     SDL_Texture* backgroundTexture;
//     SDL_Texture* maskTexture;
//     SDL_Texture* maskedBackground;
//     SDL_Texture* playerTexture;
//
//     float digRadius = 14.0f;  // Adjusted for logical resolution
//     Player player;
//
// public:
//     DigDugGame(SDL_Renderer* rend) : renderer(rend) {
//         SDL_Texture
//         // Load your background texture
//         backgroundTexture = IMG_LoadTexture(renderer, "Resources/Sprites/DigDugBackground.png");
//         if (!backgroundTexture) {
//             SDL_Log("Failed to load texture.png: %s", SDL_GetError());
//             // Create fallback texture
//             backgroundTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                                  SDL_TEXTUREACCESS_TARGET,
//                                                  LOGICAL_WIDTH, LOGICAL_HEIGHT);
//             SDL_SetRenderTarget(renderer, backgroundTexture);
//             for (int y = 0; y < LOGICAL_HEIGHT; y++) {
//                 for (int x = 0; x < LOGICAL_WIDTH; x++) {
//                     Uint8 r = (Uint8)(x * 255 / LOGICAL_WIDTH);
//                     Uint8 g = (Uint8)(y * 255 / LOGICAL_HEIGHT);
//                     Uint8 b = 128;
//                     SDL_SetRenderDrawColor(renderer, r, g, b, 255);
//                     SDL_RenderPoint(renderer, x, y);
//                 }
//             }
//             SDL_SetRenderTarget(renderer, NULL);
//         }
//
//         // Create mask texture
//         maskTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                        SDL_TEXTUREACCESS_TARGET,
//                                        LOGICAL_WIDTH, LOGICAL_HEIGHT);
//         SDL_SetTextureBlendMode(maskTexture, SDL_BLENDMODE_BLEND);
//
//         // Initialize mask to white (fully visible)
//         SDL_SetRenderTarget(renderer, maskTexture);
//         SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
//         SDL_RenderClear(renderer);
//         SDL_SetRenderTarget(renderer, NULL);
//
//         // Create result texture
//         maskedBackground = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                         SDL_TEXTUREACCESS_TARGET,
//                                         LOGICAL_WIDTH, LOGICAL_HEIGHT);
//
//         // Create initial hole at player position
//         player.x = LOGICAL_WIDTH / 2;
//         player.y = 30;
//         DigCircle(player.x, player.y, 15.0f);
//
//         // Load or create player texture
//         playerTexture = IMG_LoadTexture(renderer, "player.png");
//         if (!playerTexture) {
//             // Create a simple circle texture (smaller for logical resolution)
//             playerTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                              SDL_TEXTUREACCESS_TARGET, 32, 32);
//             SDL_SetRenderTarget(renderer, playerTexture);
//             SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
//             SDL_RenderClear(renderer);
//
//             // Draw circle
//             for (int y = 0; y < 32; y++) {
//                 for (int x = 0; x < 32; x++) {
//                     float dx = x - 16;
//                     float dy = y - 16;
//                     float dist = sqrt(dx*dx + dy*dy);
//                     if (dist < 15) {
//                         float alpha = 1.0f - (dist / 15.0f);
//                         SDL_SetRenderDrawColor(renderer, 255, 50, 50,
//                                               (Uint8)(alpha * 255));
//                         SDL_RenderPoint(renderer, x, y);
//                     }
//                 }
//             }
//             SDL_SetRenderTarget(renderer, NULL);
//         }
//     }
//
//     ~DigDugGame() {
//         SDL_DestroyTexture(backgroundTexture);
//         SDL_DestroyTexture(maskTexture);
//         SDL_DestroyTexture(maskedBackground);
//         SDL_DestroyTexture(playerTexture);
//     }
//
//     void DigCircle(float cx, float cy, float radius) {
//         SDL_SetRenderTarget(renderer, maskTexture);
//         // SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
//
//         // Fill the center completely black        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
//         // SDL_RenderLine(renderer, cx, cy, cx, cy);
//         for (int y = (int)(cy - radius * 0.7f); y <= (int)(cy + radius * 0.7f); y++) {
//             if (y < 0 || y >= LOGICAL_HEIGHT) continue;
//
//             for (int x = (int)(cx - radius * 0.7f); x <= (int)(cx + radius * 0.7f); x++) {
//                 if (x < 0 || x >= LOGICAL_WIDTH) continue;
//
//                 float dx = x - cx;
//                 float dy = y - cy;
//                 float dist = sqrt(dx*dx + dy*dy);
//
//                 if (dist <= radius * 0.7f) {
//                     SDL_RenderPoint(renderer, x, y);
//                 }
//             }
//         }
//
//         SDL_SetRenderTarget(renderer, NULL);
//     }
//
//     void ApplyMask() {
//         SDL_SetRenderTarget(renderer, maskedBackground);
//         // SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
//         // SDL_RenderClear(renderer);
//         // SDL_SetTextureBlendMode(backgroundTexture, SDL_BLENDMODE_NONE);        SDL_RenderTexture(renderer, backgroundTexture, NULL, NULL);
//
//         SDL_SetTextureBlendMode(maskTexture, SDL_BLENDMODE_MOD);
//         SDL_RenderTexture(renderer, maskTexture, NULL, NULL);
//
//         SDL_SetRenderTarget(renderer, NULL);
//     }
//
//     void HandleInput(const bool* keyState, float deltaTime) {
//         float targetDirX = 0, targetDirY = 0;
//
//         if (keyState[SDL_SCANCODE_LEFT] || keyState[SDL_SCANCODE_A]) targetDirX = -1;
//         if (keyState[SDL_SCANCODE_RIGHT] || keyState[SDL_SCANCODE_D]) targetDirX = 1;
//         if (keyState[SDL_SCANCODE_UP] || keyState[SDL_SCANCODE_W]) targetDirY = -1;
//         if (keyState[SDL_SCANCODE_DOWN] || keyState[SDL_SCANCODE_S]) targetDirY = 1;
//
//         float smoothing = 10.0f;
//         player.dirX += (targetDirX - player.dirX) * smoothing * deltaTime;
//         player.dirY += (targetDirY - player.dirY) * smoothing * deltaTime;
//
//         float length = sqrt(player.dirX*player.dirX + player.dirY*player.dirY);
//         if (length > 1.0f) {
//             player.dirX /= length;
//             player.dirY /= length;
//         }
//
//         player.x += player.dirX * player.speed * deltaTime;
//         player.y += player.dirY * player.speed * deltaTime;
//
//         player.x = fmax(player.radius, fmin(LOGICAL_WIDTH - player.radius, player.x));
//         player.y = fmax(player.radius, fmin(LOGICAL_HEIGHT - player.radius, player.y));
//
//         if (length > 0.1f) {
//             DigCircle(player.x, player.y, digRadius);
//         }
//     }
//
//     void Render() {
//         ApplyMask();
//
//         // Set render target back to window (logical resolution is already set)
//         // SDL_SetRenderTarget(renderer, NULL);        //        // SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);        // SDL_RenderClear(renderer);
//         // Draw the masked background (will automatically scale to window)        SDL_RenderTexture(renderer, maskedBackground, NULL, NULL);
//
//         // Render player
//         SDL_FRect playerRect = {
//             player.x - player.radius * 2,
//             player.y - player.radius * 2,
//             player.radius * 4,
//             player.radius * 4
//         };
//
//         double angle = 0;
//         if (fabs(player.dirX) > 0.1f || fabs(player.dirY) > 0.1f) {
//             angle = atan2(p// #include <SDL3/SDL.h>
// #include <SDL3_image/SDL_image.h>
// #include <vector>
// #include <cmath>
//
// const int LOGICAL_WIDTH = 224;
// const int LOGICAL_HEIGHT = 288;
// const int WINDOW_WIDTH = 448;   // 2x scale
// const int WINDOW_HEIGHT = 576;  // 2x scale
//
// struct Player {
//     float x, y;
//     float speed = 75.0f;  // Reduced speed for smaller resolution
//     float dirX = 0, dirY = 0;
//     float radius = 8.0f;  // Smaller player for the resolution
// };
//
// class DigDugGame {
// private:
//     SDL_Renderer* renderer;
//     SDL_Texture* backgroundTexture;
//     SDL_Texture* maskTexture;
//     SDL_Texture* maskedBackground;
//     SDL_Texture* playerTexture;
//
//     float digRadius = 14.0f;  // Adjusted for logical resolution
//     Player player;
//
// public:
//     DigDugGame(SDL_Renderer* rend) : renderer(rend) {
//         SDL_Texture
//         // Load your background texture
//         backgroundTexture = IMG_LoadTexture(renderer, "Resources/Sprites/DigDugBackground.png");
//         if (!backgroundTexture) {
//             SDL_Log("Failed to load texture.png: %s", SDL_GetError());
//             // Create fallback texture
//             backgroundTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                                  SDL_TEXTUREACCESS_TARGET,
//                                                  LOGICAL_WIDTH, LOGICAL_HEIGHT);
//             SDL_SetRenderTarget(renderer, backgroundTexture);
//             for (int y = 0; y < LOGICAL_HEIGHT; y++) {
//                 for (int x = 0; x < LOGICAL_WIDTH; x++) {
//                     Uint8 r = (Uint8)(x * 255 / LOGICAL_WIDTH);
//                     Uint8 g = (Uint8)(y * 255 / LOGICAL_HEIGHT);
//                     Uint8 b = 128;
//                     SDL_SetRenderDrawColor(renderer, r, g, b, 255);
//                     SDL_RenderPoint(renderer, x, y);
//                 }
//             }
//             SDL_SetRenderTarget(renderer, NULL);
//         }
//
//         // Create mask texture
//         maskTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                        SDL_TEXTUREACCESS_TARGET,
//                                        LOGICAL_WIDTH, LOGICAL_HEIGHT);
//         SDL_SetTextureBlendMode(maskTexture, SDL_BLENDMODE_BLEND);
//
//         // Initialize mask to white (fully visible)
//         SDL_SetRenderTarget(renderer, maskTexture);
//         SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
//         SDL_RenderClear(renderer);
//         SDL_SetRenderTarget(renderer, NULL);
//
//         // Create result texture
//         maskedBackground = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                         SDL_TEXTUREACCESS_TARGET,
//                                         LOGICAL_WIDTH, LOGICAL_HEIGHT);
//
//         // Create initial hole at player position
//         player.x = LOGICAL_WIDTH / 2;
//         player.y = 30;
//         DigCircle(player.x, player.y, 15.0f);
//
//         // Load or create player texture
//         playerTexture = IMG_LoadTexture(renderer, "player.png");
//         if (!playerTexture) {
//             // Create a simple circle texture (smaller for logical resolution)
//             playerTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
//                                              SDL_TEXTUREACCESS_TARGET, 32, 32);
//             SDL_SetRenderTarget(renderer, playerTexture);
//             SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
//             SDL_RenderClear(renderer);
//
//             // Draw circle
//             for (int y = 0; y < 32; y++) {
//                 for (int x = 0; x < 32; x++) {
//                     float dx = x - 16;
//                     float dy = y - 16;
//                     float dist = sqrt(dx*dx + dy*dy);
//                     if (dist < 15) {
//                         float alpha = 1.0f - (dist / 15.0f);
//                         SDL_SetRenderDrawColor(renderer, 255, 50, 50,
//                                               (Uint8)(alpha * 255));
//                         SDL_RenderPoint(renderer, x, y);
//                     }
//                 }
//             }
//             SDL_SetRenderTarget(renderer, NULL);
//         }
//     }
//
//     ~DigDugGame() {
//         SDL_DestroyTexture(backgroundTexture);
//         SDL_DestroyTexture(maskTexture);
//         SDL_DestroyTexture(maskedBackground);
//         SDL_DestroyTexture(playerTexture);
//     }
//
//     void DigCircle(float cx, float cy, float radius) {
//         SDL_SetRenderTarget(renderer, maskTexture);
//         // SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
//
//         // Fill the center completely black        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
//         // SDL_RenderLine(renderer, cx, cy, cx, cy);
//         for (int y = (int)(cy - radius * 0.7f); y <= (int)(cy + radius * 0.7f); y++) {
//             if (y < 0 || y >= LOGICAL_HEIGHT) continue;
//
//             for (int x = (int)(cx - radius * 0.7f); x <= (int)(cx + radius * 0.7f); x++) {
//                 if (x < 0 || x >= LOGICAL_WIDTH) continue;
//
//                 float dx = x - cx;
//                 float dy = y - cy;
//                 float dist = sqrt(dx*dx + dy*dy);
//
//                 if (dist <= radius * 0.7f) {
//                     SDL_RenderPoint(renderer, x, y);
//                 }
//             }
//         }
//
//         SDL_SetRenderTarget(renderer, NULL);
//     }
//
//     void ApplyMask() {
//         SDL_SetRenderTarget(renderer, maskedBackground);
//         // SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
//         // SDL_RenderClear(renderer);
//         // SDL_SetTextureBlendMode(backgroundTexture, SDL_BLENDMODE_NONE);        SDL_RenderTexture(renderer, backgroundTexture, NULL, NULL);
//
//         SDL_SetTextureBlendMode(maskTexture, SDL_BLENDMODE_MOD);
//         SDL_RenderTexture(renderer, maskTexture, NULL, NULL);
//
//         SDL_SetRenderTarget(renderer, NULL);
//     }
//
//     void HandleInput(const bool* keyState, float deltaTime) {
//         float targetDirX = 0, targetDirY = 0;
//
//         if (keyState[SDL_SCANCODE_LEFT] || keyState[SDL_SCANCODE_A]) targetDirX = -1;
//         if (keyState[SDL_SCANCODE_RIGHT] || keyState[SDL_SCANCODE_D]) targetDirX = 1;
//         if (keyState[SDL_SCANCODE_UP] || keyState[SDL_SCANCODE_W]) targetDirY = -1;
//         if (keyState[SDL_SCANCODE_DOWN] || keyState[SDL_SCANCODE_S]) targetDirY = 1;
//
//         float smoothing = 10.0f;
//         player.dirX += (targetDirX - player.dirX) * smoothing * deltaTime;
//         player.dirY += (targetDirY - player.dirY) * smoothing * deltaTime;
//
//         float length = sqrt(player.dirX*player.dirX + player.dirY*player.dirY);
//         if (length > 1.0f) {
//             player.dirX /= length;
//             player.dirY /= length;
//         }
//
//         player.x += player.dirX * player.speed * deltaTime;
//         player.y += player.dirY * player.speed * deltaTime;
//
//         player.x = fmax(player.radius, fmin(LOGICAL_WIDTH - player.radius, player.x));
//         player.y = fmax(player.radius, fmin(LOGICAL_HEIGHT - player.radius, player.y));
//
//         if (length > 0.1f) {
//             DigCircle(player.x, player.y, digRadius);
//         }
//     }
//
//     void Render() {
//         ApplyMask();
//
//         // Set render target back to window (logical resolution is already set)
//         // SDL_SetRenderTarget(renderer, NULL);        //        // SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);        // SDL_RenderClear(renderer);
//         // Draw the masked background (will automatically scale to window)        SDL_RenderTexture(renderer, maskedBackground, NULL, NULL);
//
//         // Render player
//         SDL_FRect playerRect = {
//             player.x - player.radius * 2,
//             player.y - player.radius * 2,
//             player.radius * 4,
//             player.radius * 4
//         };
//
//         double angle = 0;
//         if (fabs(player.dirX) > 0.1f || fabs(player.dirY) > 0.1f) {
//             angle = atan2(player.dirY, player.dirX) * 180.0 / M_PI;
//         }
//
//         SDL_RenderTextureRotated(renderer, playerTexture, NULL, &playerRect,
//                                 angle, NULL, SDL_FLIP_NONE);
//
//         // Particle effects
//         if (fabs(player.dirX) > 0.1f || fabs(player.dirY) > 0.1f) {
//             SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
//
//             for (int i = 0; i < 8; i++) {
//                 float angle_offset = (rand() % 360) * M_PI / 180.0f;
//                 float particle_dist = 10.0f + (rand() % 15);
//                 float px = player.x + cos(angle_offset) * particle_dist;
//                 float py = player.y + sin(angle_offset) * particle_dist;
//                 float particle_alpha = 100 + (rand() % 100);
//
//                 SDL_SetRenderDrawColor(renderer, 139, 69, 19, (Uint8)particle_alpha);
//                 SDL_FRect particleRect = {px - 1, py - 1, 2, 2};
//                 SDL_RenderFillRect(renderer, &particleRect);
//             }
//         }
//     }
// };
//
// int main(int argc, char* argv[]) {
//     SDL_Init(SDL_INIT_VIDEO);
//
//     // Create window with initial size
//     SDL_Window* window = SDL_CreateWindow("Texture Masking - Dig Dug Style",
//                                           WINDOW_WIDTH, WINDOW_HEIGHT,
//                                           SDL_WINDOW_RESIZABLE);  // Make resizable
//
//     SDL_Renderer* renderer = SDL_CreateRenderer(window, NULL);
//
//     // KEY CHANGE: Set logical resolution
//     // This makes SDL treat all coordinates as if the window is 224x288    // and automatically scales everything to fit the actual window    SDL_SetRenderLogicalPresentation(renderer, LOGICAL_WIDTH, LOGICAL_HEIGHT,
//                                      SDL_LOGICAL_PRESENTATION_LETTERBOX);
//
//     // Optional: Set integer scaling for pixel-perfect scaling
//     // SDL_SetRenderLogicalPresentation(renderer, LOGICAL_WIDTH, LOGICAL_HEIGHT,    //                                  SDL_LOGICAL_PRESENTATION_INTEGER_SCALE);
//     DigDugGame game(renderer);
//
//     bool quit = false;
//     SDL_Event event;
//     Uint32 lastTime = SDL_GetTicks();
//
//     while (!quit) {
//         Uint32 currentTime = SDL_GetTicks();
//         float deltaTime = (currentTime - lastTime) / 1000.0f;
//         lastTime = currentTime;
//
//         if (deltaTime > 0.05f) deltaTime = 0.05f;
//
//         while (SDL_PollEvent(&event)) {
//             if (event.type == SDL_EVENT_QUIT) {
//                 quit = true;
//             }
//         }
//
//         const bool* keyState = SDL_GetKeyboardState(NULL);
//
//         game.HandleInput(keyState, deltaTime);
//         game.Render();
//
//         SDL_RenderPresent(renderer);
//     }
//
//     SDL_DestroyRenderer(renderer);
//     SDL_DestroyWindow(window);
//     SDL_Quit();
//
//     return 0;
// }
// layer.dirY, player.dirX) * 180.0 / M_PI;
//         }
//
//         SDL_RenderTextureRotated(renderer, playerTexture, NULL, &playerRect,
//                                 angle, NULL, SDL_FLIP_NONE);
//
//         // Particle effects
//         if (fabs(player.dirX) > 0.1f || fabs(player.dirY) > 0.1f) {
//             SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
//
//             for (int i = 0; i < 8; i++) {
//                 float angle_offset = (rand() % 360) * M_PI / 180.0f;
//                 float particle_dist = 10.0f + (rand() % 15);
//                 float px = player.x + cos(angle_offset) * particle_dist;
//                 float py = player.y + sin(angle_offset) * particle_dist;
//                 float particle_alpha = 100 + (rand() % 100);
//
//                 SDL_SetRenderDrawColor(renderer, 139, 69, 19, (Uint8)particle_alpha);
//                 SDL_FRect particleRect = {px - 1, py - 1, 2, 2};
//                 SDL_RenderFillRect(renderer, &particleRect);
//             }
//         }
//     }
// };
//
// int main(int argc, char* argv[]) {
//     SDL_Init(SDL_INIT_VIDEO);
//
//     // Create window with initial size
//     SDL_Window* window = SDL_CreateWindow("Texture Masking - Dig Dug Style",
//                                           WINDOW_WIDTH, WINDOW_HEIGHT,
//                                           SDL_WINDOW_RESIZABLE);  // Make resizable
//
//     SDL_Renderer* renderer = SDL_CreateRenderer(window, NULL);
//
//     // KEY CHANGE: Set logical resolution
//     // This makes SDL treat all coordinates as if the window is 224x288    // and automatically scales everything to fit the actual window    SDL_SetRenderLogicalPresentation(renderer, LOGICAL_WIDTH, LOGICAL_HEIGHT,
//                                      SDL_LOGICAL_PRESENTATION_LETTERBOX);
//
//     // Optional: Set integer scaling for pixel-perfect scaling
//     // SDL_SetRenderLogicalPresentation(renderer, LOGICAL_WIDTH, LOGICAL_HEIGHT,    //                                  SDL_LOGICAL_PRESENTATION_INTEGER_SCALE);
//     DigDugGame game(renderer);
//
//     bool quit = false;
//     SDL_Event event;
//     Uint32 lastTime = SDL_GetTicks();
//
//     while (!quit) {
//         Uint32 currentTime = SDL_GetTicks();
//         float deltaTime = (currentTime - lastTime) / 1000.0f;
//         lastTime = currentTime;
//
//         if (deltaTime > 0.05f) deltaTime = 0.05f;
//
//         while (SDL_PollEvent(&event)) {
//             if (event.type == SDL_EVENT_QUIT) {
//                 quit = true;
//             }
//         }
//
//         const bool* keyState = SDL_GetKeyboardState(NULL);
//
//         game.HandleInput(keyState, deltaTime);
//         game.Render();
//
//         SDL_RenderPresent(renderer);
//     }
//
//     SDL_DestroyRenderer(renderer);
//     SDL_DestroyWindow(window);
//     SDL_Quit();
//
//     return 0;
// }
