#ifndef ENGINE_COMPONENTS
#define ENGINE_COMPONENTS

// Engine
#include "Engine/Components/ComponentBase.h"
#include "Engine/Rendering/Renderer.h"
#include "Engine/Rendering/Sprite.h"
// Third-party
#include <SDL3/SDL_pixels.h>
#include "glm/ext/scalar_constants.hpp"
#include "glm/vec2.hpp"
// Standard
#include <memory>
#include <string_view>
#include <string>
#include <functional>
#include <optional>

namespace Engine
{
    class GameObject;
    class Sprite;
    class Font;

    /*******************************************
     * Render component
     *******************************************/

    class RenderComponent final : public Component {
    public:
        explicit RenderComponent(GameObject& owner, Sprite::View const&) noexcept;
        ~RenderComponent() override;
        RenderComponent(RenderComponent const&) = delete;
        RenderComponent(RenderComponent&&) = delete;
        RenderComponent& operator= (RenderComponent const&) = delete;
        RenderComponent& operator= (RenderComponent&&) = delete;

        void Render() const noexcept;
        void SetSpriteView(Sprite::View const&) noexcept;
        [[nodiscard]] glm::vec2 GetSpriteViewDims() const noexcept;
        void SetFlipMode(SDL_FlipMode const flipMode){ m_flipMode = flipMode; };
        void SetRotation(float const degrees){ m_degrees = degrees; };

    private:
        Sprite::View m_spriteView;
        std::function<void()> m_renderFunction{ [this]{this->Render();} };
        SDL_FlipMode m_flipMode{};
        float m_degrees{};
    };

    /*******************************************
    * Debug component
    *******************************************/
    // Interface for components to provide debug rendering
    class DebugComponent : public Component
    {
    public:
        explicit DebugComponent(GameObject& owner, Renderer&) noexcept;
        ~DebugComponent() override;
        DebugComponent(DebugComponent&&) noexcept = delete;
        DebugComponent(DebugComponent const&) noexcept = delete;
        DebugComponent& operator=(DebugComponent const&) noexcept = delete;
        DebugComponent& operator=(DebugComponent&&) noexcept = delete;

        virtual void DebugRender() = 0;

    private:
        std::function<void()> const m_debugRenderFunction{ [this]{this->DebugRender();} };
        Renderer& m_renderer;
    };

    /*******************************************
     * Text component
     *******************************************/
    class TextComponent final : public Component {
    public:
        explicit TextComponent(GameObject &owner,
                               std::string_view text, Font* pFont,
                               SDL_Color const&color = {255, 255, 255, 255}) noexcept;
        void SetFont(Font* pFont);
        void SetText(std::string_view text);
        void SetColor(SDL_Color const& color);

    private:
        std::string m_text;
        Font* m_pFont;
        std::unique_ptr<Sprite> m_pTexture{};
        SDL_Color m_color{ 255, 255, 255, 255 };
        RenderComponent& m_renderComponent;

        // Separate from UpdateTexture(), to initialize RenderComponent
        [[nodiscard]] Sprite* GetUpdatedTexture();
        void UpdateTexture();
    };

    /*******************************************
     * FPS component
     *******************************************/
    class FPSComponent final : public Component {
    public:
        explicit FPSComponent(GameObject &owner, Font* pFont,
                               SDL_Color const& color = {255, 255, 255, 255}) noexcept;
        void Update() noexcept override;
    };

    /*******************************************
     * Orbit component
     *******************************************/
    class OrbitComponent final : public Component
    {
    public:
        /**
         * Rotates the object around @center at the @distance with the speed of radians.
         * Sets the transform value to transform component
         * The distance between the component's parent and parent of the parent is preserved
         * @param owner GameObject the component belongs to
         * @param radiansSec speed, with which the object rotates around the pivot point
         * @note Requires the owner to have a parent
         */
        explicit OrbitComponent(GameObject &owner, float radiansSec) noexcept;
        void Update() noexcept override;

    private:
        float m_radiansSec{ 0.25f * glm::pi<float>() };
    };

}

#endif// ENGINE_COMPONENTS
